<?php 
//Input values:
$name = $_POST['name'];
$name = urldecode(htmlspecialchars($name));

$email = $_POST['email'];
$email = urldecode(htmlspecialchars($email));

$email_text .= "<h3>Подписка на рассылку «Рациональный малый»</h3>
<p>Имя: {$name} </p>
<p>E-mail:{$email} </p>
---- <br/>
Сообщение с лендинга «Рациональный малый»";

//Sending email:
$headers .= 'From: hello@adphone.biz' . "\r\n" ."Content-type: text/html\r\n";
mail('hello@adphone.biz', "Подписка на рассылку «Рациональный малый»", $email_text, $headers);
endif;
?>